package com.jennyai.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val BG = Color(0xFF090611)
private val CARD = Color(0xFF1A1028)
private val PINK = Color(0xFFFF4FD8)
private val PURPLE = Color(0xFF9B68FF)
private val WHITE = Color(0xFFF7F0FF)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speech: SpeechRecognizer? = null
    private var language by mutableStateOf("English")
    private var listening by mutableStateOf(false)
    private var heard by mutableStateOf("")
    private var reply by mutableStateOf("Hello! I'm Jenny. How can I help you?")
    private var status by mutableStateOf("Tap the microphone to talk")

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) listenNow() else status = "Microphone permission is required."
    }
    private val contactsPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (!it) status = "Contacts permission was not granted. Please allow it to call a saved contact."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JennyScreen() }
    }

    private fun localeNow() = if (language == "Tamil") Locale("ta", "IN") else Locale("en", "IN")

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts?.language = localeNow()
            say("Hello. I am Jenny, your personal assistant.")
        } else status = "Text to speech is unavailable."
    }

    private fun say(text: String) {
        reply = text
        tts?.language = localeNow()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jenny_reply")
    }

    private fun listenNow() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status = "Speech recognition is unavailable. Update/install Google speech services."
            return
        }
        try {
            speech?.destroy()
            speech = SpeechRecognizer.createSpeechRecognizer(this)
            speech?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening = true; status = "Listening…"}
                override fun onBeginningOfSpeech() { status = "I'm listening…"}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false; status = "Processing…"}
                override fun onError(error: Int) {
                    listening = false
                    status = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "I didn't catch that. Tap the mic and try again."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected. Please try again."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Please allow microphone access."
                        else -> "Voice input stopped. Tap the mic to retry."
                    }
                }
                override fun onResults(results: Bundle?) {
                    listening = false
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    heard = text
                    if (text.isNotBlank()) runCommand(text) else status = "I didn't hear anything."
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    heard = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeNow().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, localeNow().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            speech?.startListening(intent)
        } catch (e: Exception) {
            listening = false
            status = "Couldn't start voice input: ${e.localizedMessage ?: "unknown error"}"
        }
    }

    private fun runCommand(raw: String) {
        val command = raw.trim()
        val c = command.lowercase(Locale.ROOT)
        status = "Command received"
        when {
            c.startsWith("open ") || c.startsWith("launch ") -> openApp(c.removePrefix("open ").removePrefix("launch ").trim())
            c.startsWith("call ") || c.startsWith("dial ") -> findContact(command.substringAfter(" ").trim())
            c.contains("time") -> {
                val time = SimpleDateFormat("h:mm a", localeNow()).format(Date())
                say(if (language == "Tamil") "இப்போது நேரம் $time" else "The time is $time")
            }
            c.contains("date") || c.contains("today") -> {
                val date = SimpleDateFormat("EEEE, d MMMM yyyy", localeNow()).format(Date())
                say(if (language == "Tamil") "இன்றைய தேதி $date" else "Today is $date")
            }
            c.contains("hello") || c.contains("hey jenny") || c.contains("hi jenny") ->
                say(if (language == "Tamil") "வணக்கம்! நான் உங்களுக்கு எப்படி உதவலாம்?" else "Hello! How can I help you?")
            c.contains("help") ->
                say("Try saying: open WhatsApp, open YouTube, open Instagram, call a contact name, what time is it, or today's date.")
            else -> say(if (language == "Tamil") "நீங்கள் சொன்னது: $command. இந்த கட்டளை அடுத்த பதிப்பில் சேர்க்கப்படும்." else "I heard: $command. This command is not connected yet.")
        }
    }

    private fun openApp(name: String) {
        val item = when {
            name.contains("whatsapp") -> Triple("com.whatsapp", "https://www.whatsapp.com/", "WhatsApp")
            name.contains("youtube") -> Triple("com.google.android.youtube", "https://www.youtube.com/", "YouTube")
            name.contains("instagram") -> Triple("com.instagram.android", "https://www.instagram.com/", "Instagram")
            name.contains("spotify") -> Triple("com.spotify.music", "https://open.spotify.com/", "Spotify")
            else -> Triple("", "https://www.google.com/search?q=${Uri.encode(name)}", name)
        }
        try {
            val launch = if (item.first.isNotEmpty()) packageManager.getLaunchIntentForPackage(item.first) else null
            if (launch != null) {
                startActivity(launch)
                say("Opening ${item.third}.")
            } else {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.second)))
                say("${item.third} app was not found. Opening its website.")
            }
        } catch (_: Exception) { say("I couldn't open ${item.third}.") }
    }

    private fun findContact(name: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            contactsPermission.launch(Manifest.permission.READ_CONTACTS)
            status = "Allow Contacts permission, then repeat: call $name"
            return
        }
        try {
            val uri = Uri.withAppendedPath(ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(name))
            val cursor = contentResolver.query(uri, arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ), null, null, null)
            var foundName: String? = null
            var number: String? = null
            cursor?.use { if (it.moveToFirst()) { foundName = it.getString(0); number = it.getString(1) } }
            if (!number.isNullOrBlank()) {
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")))
                say("I found $foundName. Please confirm the call in your dialer.")
            } else say("I couldn't find a contact named $name.")
        } catch (_: Exception) { say("I couldn't search your contacts.") }
    }

    private fun openTtsSettings() {
        try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
        catch (_: Exception) { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
    }

    @Composable
    private fun JennyScreen() {
        var input by remember { mutableStateOf("") }
        var settings by remember { mutableStateOf(false) }
        val transition = rememberInfiniteTransition(label = "micPulse")
        val pulse by transition.animateFloat(1f, 1.09f, infiniteRepeatable(tween(850), RepeatMode.Reverse), label = "pulse")

        MaterialTheme(colorScheme = darkColorScheme(
            background = BG, surface = CARD, primary = PINK, secondary = PURPLE,
            onBackground = WHITE, onSurface = WHITE
        )) {
            Column(
                modifier = Modifier.fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0xFF180D27), BG, Color(0xFF100817))))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("Jenny", color = PINK, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                        Text("YOUR PERSONAL AI ASSISTANT", color = WHITE.copy(alpha = .72f), fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    IconButton(onClick = { settings = !settings }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = WHITE)
                    }
                }

                if (settings) {
                    Card(colors = CardDefaults.cardColors(containerColor = CARD), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Voice language", color = PINK, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = language == "English", onClick = { language = "English"; tts?.language = localeNow() }, label = { Text("English") })
                                FilterChip(selected = language == "Tamil", onClick = { language = "Tamil"; tts?.language = localeNow() }, label = { Text("தமிழ்") })
                            }
                            TextButton(onClick = { openTtsSettings() }) { Text("Android voice / Text-to-speech settings") }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }

                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Image(
                            painter = painterResource(R.drawable.jenny_avatar),
                            contentDescription = "Jenny professional assistant portrait",
                            modifier = Modifier.size(width = 220.dp, height = 250.dp)
                                .clip(RoundedCornerShape(26.dp)).border(1.dp, PURPLE, RoundedCornerShape(26.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Text(if (listening) "I'm listening…" else "Hello, I'm Jenny", color = WHITE, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                        Text(status, color = PINK, fontSize = 12.sp, textAlign = TextAlign.Center)
                        Box(
                            Modifier.size(104.dp).scale(if (listening) pulse else 1f)
                                .clip(CircleShape)
                                .background(Brush.radialGradient(listOf(Color(0xFF572A7A), Color(0xFF1A0D2A), BG)))
                                .border(3.dp, PINK, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            IconButton(onClick = { listenNow() }, modifier = Modifier.size(88.dp)) {
                                Icon(Icons.Default.Mic, contentDescription = "Start listening", tint = WHITE, modifier = Modifier.size(44.dp))
                            }
                        }
                        if (heard.isNotBlank()) Text("You said: $heard", color = WHITE.copy(alpha = .8f), fontSize = 12.sp, textAlign = TextAlign.Center)
                        Text(reply, color = WHITE, fontSize = 13.sp, textAlign = TextAlign.Center)
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    QuickTile("Call", Icons.Default.Call, Modifier.weight(1f)) { input = "call " }
                    QuickTile("WhatsApp", Icons.Default.Chat, Modifier.weight(1f)) { openApp("whatsapp") }
                    QuickTile("YouTube", Icons.Default.PlayArrow, Modifier.weight(1f)) { openApp("youtube") }
                    QuickTile("Instagram", Icons.Default.CameraAlt, Modifier.weight(1f)) { openApp("instagram") }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Type a command… e.g. open YouTube") },
                    singleLine = true,
                    trailingIcon = {
                        IconButton(onClick = {
                            val cmd = input.trim()
                            if (cmd.isNotEmpty()) { input = ""; runCommand(cmd) }
                        }) { Icon(Icons.Default.Send, contentDescription = "Send", tint = PINK) }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PINK, unfocusedBorderColor = PURPLE,
                        focusedTextColor = WHITE, unfocusedTextColor = WHITE
                    )
                )
                Spacer(Modifier.height(6.dp))
                Text("Tap the microphone to speak • Always-on “Hey Jenny” is a later stage", color = WHITE.copy(alpha = .55f), fontSize = 9.sp, textAlign = TextAlign.Center)
            }
        }
    }

    @Composable
    private fun QuickTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
        Card(onClick = onClick, modifier = modifier.height(68.dp), shape = RoundedCornerShape(15.dp),
            colors = CardDefaults.cardColors(containerColor = CARD)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(icon, contentDescription = label, tint = PINK)
                Text(label, color = WHITE, fontSize = 9.sp)
            }
        }
    }

    override fun onDestroy() {
        speech?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
